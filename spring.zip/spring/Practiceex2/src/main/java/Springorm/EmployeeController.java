package Springorm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class EmployeeController {

	@Autowired
	private EmpService empService;

	@GetMapping("/employees")
	public String listEmployees(Model model) {
		model.addAttribute("employees", empService.listAll());
		return "listEmployees";
	}

	@GetMapping("/addEmployee")
	public String showAddEmployeeForm(Model model) {
		model.addAttribute("employee", new EmployeeI195());
		return "addEmployee";
	}

	@PostMapping("/saveEmployee")
	public String saveEmployee(@ModelAttribute("employee") EmployeeI195 employee) {
		empService.add(employee);
		return "redirect:/employees";
	}
}
