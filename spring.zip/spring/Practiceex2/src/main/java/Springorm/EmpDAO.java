package Springorm;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;

@Component
public class EmpDAO {

	@PersistenceContext
	private EntityManager em;

	public void persist(EmployeeI195 emp) {
		em.persist(emp);
	}

	public List<EmployeeI195> findAll() {
		List<EmployeeI195> employees = em.createQuery("SELECT e FROM EmployeeI195 e", EmployeeI195.class)
				.getResultList();

		// Print the retrieved data

		System.out.println("Employee: ");

		return employees;

	}

}
