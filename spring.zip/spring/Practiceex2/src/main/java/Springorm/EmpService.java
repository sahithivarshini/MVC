package Springorm;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class EmpService {

	@Autowired
	private EmpDAO edao;

	@Transactional
	public void add(EmployeeI195 emp) {
		edao.persist(emp);
	}

	@Transactional
	public void addAll(Collection<EmployeeI195> empList) {
		for (EmployeeI195 emp : empList) {
			edao.persist(emp);
		}
	}

	@Transactional(readOnly = true)
	public List<EmployeeI195> listAll() {
		return edao.findAll();

	}

}
